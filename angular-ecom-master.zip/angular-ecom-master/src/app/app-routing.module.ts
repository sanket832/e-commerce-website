import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DashboardComponent } from './dashboard/dashboard.component';
import { TableComponent } from './table/table.component';
import { AddComponent } from './add/add.component';
import { DispalyComponent } from './dispaly/dispaly.component';
import { SaComponent } from './sa/sa.component';
import { MainComponent } from './main/main.component';
import { HomeComponent } from './home/home.component';
import { SellingAuthComponent } from './selling-auth/selling-auth.component';
import { SellerHomeComponent } from './seller-home/seller-home.component';
import { AuthGuard } from './auth.guard';
import { SellerAddProductComponent } from './seller-add-product/seller-add-product.component';
import { SellerUpdateProductComponent } from './seller-update-product/seller-update-product.component';
import { SearchComponent } from './search/search.component';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { UserAuthComponent } from './user-auth/user-auth.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { MyOrdersComponent } from './my-orders/my-orders.component';


const routes: Routes = [

 {path:'',component:HomeComponent},
 {path:'selling-auth',component:SellingAuthComponent},
 {path:'seller-home',component:SellerHomeComponent,
  canActivate:[AuthGuard]
},
{component:SellerAddProductComponent,path:'seller-add-product',
canActivate:[AuthGuard]
},
{component:SellerUpdateProductComponent,path:'seller-update-product/:id',
canActivate:[AuthGuard]
},
{
  component:SearchComponent,
  path:'search/:query'
},
{component:ProductDetailsComponent,
path:'details/:productId'
},
{component:UserAuthComponent,
path:'user-auth'
},
{
  component:CartComponent,
  path:'cart'
},
{
  component:CheckoutComponent,
  path:'checkout'
},
{
  component:MyOrdersComponent,
  path:'my-orders'
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
