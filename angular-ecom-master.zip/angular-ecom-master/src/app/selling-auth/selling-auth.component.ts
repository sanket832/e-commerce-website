import { Component,OnInit } from '@angular/core';
import { SellService } from '../service/sell.service';
import { Router } from '@angular/router';
import { SignUp, login } from '../data-type';

@Component({
  selector: 'app-selling-auth',
  templateUrl: './selling-auth.component.html',
  styleUrls: ['./selling-auth.component.css']
})
export class SellingAuthComponent implements OnInit {
  
  constructor(private seller:SellService,private router:Router){

  }
  showLogin=false;
  authError:string ='';

  ngOnInit(): void {
    this.seller.reloadSeller();
  }

  signUp(data:SignUp):void {
    console.log(data)
    this.seller.userSignUp(data)

  }
  login(data:login):void {
    this.authError="";
    //console.log(data)
   this.seller.userLogin(data);
   this.seller.isLoginError.subscribe((error)=>{
    if(error){
      this.authError="Email Or Password is Invalid"
    }

   })

  }
  
  openLogin(){
   this.showLogin=true
  }
  openSignUp(){
    this.showLogin=false
  }

}
