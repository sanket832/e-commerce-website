export interface SignUp{
    name:string,
    passwors:string,
    email:string;
}

export interface login {
    email:string,
    password:string
}
export interface product{
    name:string,
    price:number,
    category:string,
    color:string,
    description:string,
    Image:string,
    id:number,
    quantity:undefined | number,
    productId:undefined | number,
    cartItems:number

}
export interface cart{
    name:string,
    price:number,
    category:string,
    color:string,
    description:string,
    Image:string,
    id:number |undefined,
    quantity:undefined | number,
    userId:number | undefined,
    productId:number
}
export interface priceSummary{
 price:number,
 discount:number,
 tax:number,
 delivery:number,
 total:number
}
export interface order{
    email:string,
    address:string,
    contact:string,
    totalPrice:number,
    userId:string,
    id:number | undefined
    
}