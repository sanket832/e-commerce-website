import { Component } from '@angular/core';
import { UserService } from '../user.service';
@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent {
  users:any

  constructor(private api:UserService){

  }
  ngOnInit(){
    this.getuserList();
  }
  getuserList(){
    this.api.getuser().subscribe(data=>{
      console.log(data)
      this.users=data;
    })
  }
  deleteUser(item:any){
    this.api.delete(item).subscribe(data=>{
      console.log(data);
      this.getuserList();
    })
  }
}
