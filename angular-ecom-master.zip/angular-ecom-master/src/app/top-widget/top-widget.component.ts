import { Component } from '@angular/core';

@Component({
  selector: 'app-top-widget',
  templateUrl: './top-widget.component.html',
  styleUrls: ['./top-widget.component.css']
})
export class TopWidgetComponent {

}
