import { Component } from '@angular/core';
import { UserService } from '../user.service';
import { FormControl,FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-da',
  templateUrl: './da.component.html',
  styleUrls: ['./da.component.css']
})
export class DaComponent {
  
}
