import { Component,OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { FormControl, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-sa',
  templateUrl: './sa.component.html',
  styleUrls: ['./sa.component.css']
})
export class SaComponent implements OnInit{
userForm:any=FormGroup
isEditMode:boolean=false;
constructor(private api:UserService,private active:ActivatedRoute ){
  const userId=this.active.snapshot.params['id']
  if(userId){
    this.isEditMode=true;
    this.api.getById(userId).subscribe(data=>{
      console.log(data);
      this.userForm.patchValue(data);
    })

  }
}
  ngOnInit(): void {
    this.userForm=new FormGroup({
      id:new FormControl(''),
      name:new FormControl(''),
      email:new FormControl(''),
      mobile:new FormControl('')
    })
  }
  add(){
    if(this.isEditMode){
      this.api.update(this.userForm.controls.id.value,this.userForm.value).subscribe(data=>{
        console.log(data);
      })

    }
    else{
      this.api.post(this.userForm.value).subscribe(data=>{
        console.log(data);
        this.userForm=data;
      })
    }
  }

}
