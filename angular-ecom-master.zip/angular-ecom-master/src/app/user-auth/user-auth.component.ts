import { Component, OnInit } from '@angular/core';
import { SignUp, cart, login, product } from '../data-type';
import { User1Service } from '../user1.service';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-user-auth',
  templateUrl: './user-auth.component.html',
  styleUrls: ['./user-auth.component.css']
})
export class UserAuthComponent implements OnInit {
  showLogin: boolean = true;
  authError: string = "";
  constructor(private user: User1Service,private product:ProductService) { }
  ngOnInit(): void {
    this.user.userAuthReload();

  }
  signUp(data: SignUp) {

    this.user.userSignUp(data)

  }
  login(val: login) {
    this.user.userLogin(val);
    this.user.isLoginError.subscribe((result) => {
      console.log(result)
      if (result) {
        this.authError = "please Enter valid details"
      } else {
       setTimeout(() => {
        this.localCartToRemoteCart()
       }, 300);
      }
    })

  }
  openSignUp() {
    this.showLogin = false

  }
  openLogin() {
    this.showLogin = true;
  }
  localCartToRemoteCart() {
    let data = localStorage.getItem('localCart');
    let user = localStorage.getItem('user');
    let userId = user && JSON.parse(user).id;
    if (data) {
      let cartDataList: product[] = JSON.parse(data)
    


      cartDataList.forEach((product: product,index) => {
        let cartData: cart = {
          ...product,
          productId: product.id,
          userId
        };
        delete cartData.id;
       setTimeout(() => {
        this.product.addToCart(cartData).subscribe((result)=>{
          if(result){
            console.warn('item stored in DB');
            
          }
      })
      if(cartDataList.length===index+1){
        localStorage.removeItem('localCart')
      }
       }, 500);

      });
    }

   setTimeout(() => {
    this.product.getCartList(userId)
   }, 2000);
  }

}
